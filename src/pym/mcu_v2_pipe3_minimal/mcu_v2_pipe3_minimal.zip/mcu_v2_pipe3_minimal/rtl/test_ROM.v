`timescale 1ns/1ps

module test_ROM (
    input  wire       clka,
    input  wire       ena,
    input  wire [5:0] addra,
    output reg [15:0] douta
);

reg [15:0] mem [0:63];
reg [5:0] addr_d1;
reg [5:0] addr_d2;
integer k;

initial begin
    for (k = 0; k < 64; k = k + 1) begin
        mem[k] = 16'd0;
    end

    // Ĭ�ϲ������ݣ�64,63,...,1
    for (k = 0; k < 64; k = k + 1) begin
        mem[k] = 64 - k;
    end

    addr_d1 = 6'd0;
    addr_d2 = 6'd0;
    douta   = 16'd0;
end

always @(posedge clka) begin
    if (ena) begin
        addr_d1 <= addra;
        addr_d2 <= addr_d1;
        douta   <= mem[addr_d2];
    end
end

endmodule