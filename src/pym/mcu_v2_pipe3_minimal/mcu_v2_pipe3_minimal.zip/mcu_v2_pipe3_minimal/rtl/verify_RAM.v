`timescale 1ns/1ps

module verify_RAM (
    input  wire       clka,
    input  wire       ena,
    input  wire [0:0] wea,
    input  wire [5:0] addra,
    input  wire [15:0] dina,
    output reg [15:0] douta
);

reg [15:0] mem [0:63];
reg [5:0] addr_d1;
reg [5:0] addr_d2;
integer k;

initial begin
    for (k = 0; k < 64; k = k + 1) begin
        mem[k] = 16'd0;
    end

    addr_d1 = 6'd0;
    addr_d2 = 6'd0;
    douta   = 16'd0;
end

always @(posedge clka) begin
    if (ena) begin
        if (wea[0]) begin
            mem[addra] <= dina;
        end

        addr_d1 <= addra;
        addr_d2 <= addr_d1;
        douta   <= mem[addr_d2];
    end
end

endmodule