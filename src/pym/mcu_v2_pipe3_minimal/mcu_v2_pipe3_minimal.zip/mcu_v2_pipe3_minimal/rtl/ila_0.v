`timescale 1ns/1ps

// Synthesis/simulation stub for ila_0.
// This placeholder is used only to make the design compile
// when the real Vivado ILA IP has not been generated yet.
//
// For real board debugging, replace this file with Vivado IP Catalog -> ILA.

module ila_0 (
    input  wire        clk,
    input  wire [15:0] probe0,
    input  wire [15:0] probe1,
    input  wire [19:0] probe2,
    input  wire [2:0]  probe3,
    input  wire [31:0] probe4
);

endmodule