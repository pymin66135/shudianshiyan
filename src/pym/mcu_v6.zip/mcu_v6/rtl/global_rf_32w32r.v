//============================================================
// Module: global_rf_32w32r
// Description:
//   Global register file for V6.0 32-core sorting architecture.
//   64 depth x 16-bit, 32 read ports (combinational), 32 write ports (sync).
//============================================================

`timescale 1ns/1ps

module global_rf_32w32r (
    input  wire        clk,
    input  wire        rst_n,

    input  wire [5:0]  raddr0, raddr1, raddr2, raddr3,
    input  wire [5:0]  raddr4, raddr5, raddr6, raddr7,
    input  wire [5:0]  raddr8, raddr9, raddr10, raddr11,
    input  wire [5:0]  raddr12, raddr13, raddr14, raddr15,
    input  wire [5:0]  raddr16, raddr17, raddr18, raddr19,
    input  wire [5:0]  raddr20, raddr21, raddr22, raddr23,
    input  wire [5:0]  raddr24, raddr25, raddr26, raddr27,
    input  wire [5:0]  raddr28, raddr29, raddr30, raddr31,
    output wire [15:0] rdata0, rdata1, rdata2, rdata3,
    output wire [15:0] rdata4, rdata5, rdata6, rdata7,
    output wire [15:0] rdata8, rdata9, rdata10, rdata11,
    output wire [15:0] rdata12, rdata13, rdata14, rdata15,
    output wire [15:0] rdata16, rdata17, rdata18, rdata19,
    output wire [15:0] rdata20, rdata21, rdata22, rdata23,
    output wire [15:0] rdata24, rdata25, rdata26, rdata27,
    output wire [15:0] rdata28, rdata29, rdata30, rdata31,

    input  wire [5:0]  waddr0, waddr1, waddr2, waddr3,
    input  wire [5:0]  waddr4, waddr5, waddr6, waddr7,
    input  wire [5:0]  waddr8, waddr9, waddr10, waddr11,
    input  wire [5:0]  waddr12, waddr13, waddr14, waddr15,
    input  wire [5:0]  waddr16, waddr17, waddr18, waddr19,
    input  wire [5:0]  waddr20, waddr21, waddr22, waddr23,
    input  wire [5:0]  waddr24, waddr25, waddr26, waddr27,
    input  wire [5:0]  waddr28, waddr29, waddr30, waddr31,
    input  wire [15:0] wdata0, wdata1, wdata2, wdata3,
    input  wire [15:0] wdata4, wdata5, wdata6, wdata7,
    input  wire [15:0] wdata8, wdata9, wdata10, wdata11,
    input  wire [15:0] wdata12, wdata13, wdata14, wdata15,
    input  wire [15:0] wdata16, wdata17, wdata18, wdata19,
    input  wire [15:0] wdata20, wdata21, wdata22, wdata23,
    input  wire [15:0] wdata24, wdata25, wdata26, wdata27,
    input  wire [15:0] wdata28, wdata29, wdata30, wdata31,
    input  wire        we0, we1, we2, we3,
    input  wire        we4, we5, we6, we7,
    input  wire        we8, we9, we10, we11,
    input  wire        we12, we13, we14, we15,
    input  wire        we16, we17, we18, we19,
    input  wire        we20, we21, we22, we23,
    input  wire        we24, we25, we26, we27,
    input  wire        we28, we29, we30, we31
);

reg [15:0] regs [0:63];
integer i;

assign rdata0=regs[raddr0]; assign rdata1=regs[raddr1];
assign rdata2=regs[raddr2]; assign rdata3=regs[raddr3];
assign rdata4=regs[raddr4]; assign rdata5=regs[raddr5];
assign rdata6=regs[raddr6]; assign rdata7=regs[raddr7];
assign rdata8=regs[raddr8]; assign rdata9=regs[raddr9];
assign rdata10=regs[raddr10]; assign rdata11=regs[raddr11];
assign rdata12=regs[raddr12]; assign rdata13=regs[raddr13];
assign rdata14=regs[raddr14]; assign rdata15=regs[raddr15];
assign rdata16=regs[raddr16]; assign rdata17=regs[raddr17];
assign rdata18=regs[raddr18]; assign rdata19=regs[raddr19];
assign rdata20=regs[raddr20]; assign rdata21=regs[raddr21];
assign rdata22=regs[raddr22]; assign rdata23=regs[raddr23];
assign rdata24=regs[raddr24]; assign rdata25=regs[raddr25];
assign rdata26=regs[raddr26]; assign rdata27=regs[raddr27];
assign rdata28=regs[raddr28]; assign rdata29=regs[raddr29];
assign rdata30=regs[raddr30]; assign rdata31=regs[raddr31];

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        for (i=0; i<64; i=i+1) regs[i] <= 16'b0;
    end else begin
        if (we0)  regs[waddr0]  <= wdata0;
        if (we1)  regs[waddr1]  <= wdata1;
        if (we2)  regs[waddr2]  <= wdata2;
        if (we3)  regs[waddr3]  <= wdata3;
        if (we4)  regs[waddr4]  <= wdata4;
        if (we5)  regs[waddr5]  <= wdata5;
        if (we6)  regs[waddr6]  <= wdata6;
        if (we7)  regs[waddr7]  <= wdata7;
        if (we8)  regs[waddr8]  <= wdata8;
        if (we9)  regs[waddr9]  <= wdata9;
        if (we10) regs[waddr10] <= wdata10;
        if (we11) regs[waddr11] <= wdata11;
        if (we12) regs[waddr12] <= wdata12;
        if (we13) regs[waddr13] <= wdata13;
        if (we14) regs[waddr14] <= wdata14;
        if (we15) regs[waddr15] <= wdata15;
        if (we16) regs[waddr16] <= wdata16;
        if (we17) regs[waddr17] <= wdata17;
        if (we18) regs[waddr18] <= wdata18;
        if (we19) regs[waddr19] <= wdata19;
        if (we20) regs[waddr20] <= wdata20;
        if (we21) regs[waddr21] <= wdata21;
        if (we22) regs[waddr22] <= wdata22;
        if (we23) regs[waddr23] <= wdata23;
        if (we24) regs[waddr24] <= wdata24;
        if (we25) regs[waddr25] <= wdata25;
        if (we26) regs[waddr26] <= wdata26;
        if (we27) regs[waddr27] <= wdata27;
        if (we28) regs[waddr28] <= wdata28;
        if (we29) regs[waddr29] <= wdata29;
        if (we30) regs[waddr30] <= wdata30;
        if (we31) regs[waddr31] <= wdata31;
    end
end

endmodule
