#!/usr/bin/env python3
"""
========================================================================
V6.0 32-Core Sort Program Generator
========================================================================
32核架构，每核2元素。完整Batcher-64网络+32核深度分层锁步。
========================================================================
"""

import os


def batcher_sort(lo, n):
    if n <= 1: return []
    m = n // 2; p = []
    p.extend(batcher_sort(lo, m)); p.extend(batcher_sort(lo + m, m))
    p.extend(batcher_merge(lo, n, 1))
    return p


def batcher_merge(lo, n, r):
    m = r * 2; p = []
    if m < n:
        p.extend(batcher_merge(lo, n, m)); p.extend(batcher_merge(lo + r, n, m))
        for i in range(lo + r, lo + n - r, m): p.append((i, i + r))
    else: p.append((lo, lo + r))
    return p


def enc_ldr(rd, rn, offset):
    return 0xE5900000 | (rn << 16) | (rd << 12) | (offset & 0xFFF)


def enc_str_cond(rd, rn, offset, cond=0xE):
    return (cond << 28) | 0x05800000 | (rn << 16) | (rd << 12) | (offset & 0xFFF)


def enc_subs(rd, rn, rm):
    return 0xE0500000 | (rn << 16) | (rd << 12) | (rm & 0xF)


def gprf_cas(a, b):
    return [
        enc_ldr(0, 7, a * 2), enc_ldr(1, 7, b * 2),
        enc_subs(2, 0, 1),
        enc_str_cond(1, 7, a * 2, 0xC), enc_str_cond(0, 7, b * 2, 0xC),
    ]


def gprf_cas_dummy():
    return [0xE1A00000] * 5


def main():
    N_TOTAL = 64
    N_CORES = 32
    print("V6.0 32-Core: Full Batcher-64 (depth-layered across 32 cores)")

    all_pairs = batcher_sort(0, N_TOTAL)
    print(f"  Batcher-64 pairs: {len(all_pairs)}")

    depth = {i: 0 for i in range(N_TOTAL)}
    layers = {}
    for a, b in all_pairs:
        d = max(depth[a], depth[b]) + 1
        depth[a] = depth[b] = d
        layers.setdefault(d, []).append((a, b))
    print(f"  Layers: {len(layers)}")

    core_instrs = [[] for _ in range(N_CORES)]
    for d in sorted(layers.keys()):
        lp = layers[d]
        for i in range(0, len(lp), N_CORES):
            for c in range(N_CORES):
                if i + c < len(lp):
                    a, b = lp[i + c]
                    core_instrs[c].extend(gprf_cas(a, b))
                else:
                    core_instrs[c].extend(gprf_cas_dummy())

    for c in range(N_CORES):
        print(f"  core_{c:02d}: {len(core_instrs[c])} instrs")

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "programs")
    os.makedirs(out_dir, exist_ok=True)
    print(f"\nWriting to: {out_dir}")
    done_pcs = []
    for c in range(N_CORES):
        path = os.path.join(out_dir, f"core_{c:02d}.hex")
        with open(path, "w") as f:
            for instr in core_instrs[c]:
                f.write(f"{instr:08X}\n")
        dpc = len(core_instrs[c]) * 4
        done_pcs.append(dpc)
        print(f"  core_{c:02d}.hex: {len(core_instrs[c])} instrs, DONE_PC=0x{dpc:08X}")

    print("\nDONE_PC values for top.v:")
    for c, dpc in enumerate(done_pcs):
        print(f"  DONE_PC_CORE{c:02d} = 32'h{dpc:08X};")


if __name__ == "__main__":
    main()
