//============================================================
// Module: tb_top_v6_32core
// Description:
//   V6.0 32-core testbench. Uses COE-initialized test_ROM,
//   waits for ST_DONE, samples verify_vector_out for verification.
//============================================================

`timescale 1ns/1ps

module tb_top_v6_32core;

    localparam N_DATA = 64;
    localparam [31:0] DONE_PC = 32'h000001A4;

    reg clk_osc;
    reg rst;
    integer timeout, i;
    reg [15:0] result [0:N_DATA-1];
    integer err_cnt;

    initial begin
        clk_osc = 1'b0;
        forever #5 clk_osc = ~clk_osc;
    end

    top #(
        .DONE_PC_CORE00(DONE_PC), .DONE_PC_CORE01(DONE_PC), .DONE_PC_CORE02(DONE_PC), .DONE_PC_CORE03(DONE_PC),
        .DONE_PC_CORE04(DONE_PC), .DONE_PC_CORE05(DONE_PC), .DONE_PC_CORE06(DONE_PC), .DONE_PC_CORE07(DONE_PC),
        .DONE_PC_CORE08(DONE_PC), .DONE_PC_CORE09(DONE_PC), .DONE_PC_CORE10(DONE_PC), .DONE_PC_CORE11(DONE_PC),
        .DONE_PC_CORE12(DONE_PC), .DONE_PC_CORE13(DONE_PC), .DONE_PC_CORE14(DONE_PC), .DONE_PC_CORE15(DONE_PC),
        .DONE_PC_CORE16(DONE_PC), .DONE_PC_CORE17(DONE_PC), .DONE_PC_CORE18(DONE_PC), .DONE_PC_CORE19(DONE_PC),
        .DONE_PC_CORE20(DONE_PC), .DONE_PC_CORE21(DONE_PC), .DONE_PC_CORE22(DONE_PC), .DONE_PC_CORE23(DONE_PC),
        .DONE_PC_CORE24(DONE_PC), .DONE_PC_CORE25(DONE_PC), .DONE_PC_CORE26(DONE_PC), .DONE_PC_CORE27(DONE_PC),
        .DONE_PC_CORE28(DONE_PC), .DONE_PC_CORE29(DONE_PC), .DONE_PC_CORE30(DONE_PC), .DONE_PC_CORE31(DONE_PC)
    ) dut (
        .clk_osc(clk_osc), .rst(rst)
    );

    always @(posedge clk_osc) begin
        if (dut.verify_ram_en) begin
            result[dut.verify_ram_addr] <= dut.verify_vector_out;
        end
    end

    initial begin
        $display("============================================================");
        $display(" V6.0 32-Core Testbench (COE data)");
        $display("============================================================");

        rst = 1'b1;
        #100;
        rst = 1'b0;
        timeout = 0;

        while (dut.done !== 1'b1 && timeout < 50000) begin
            @(posedge clk_osc);
            timeout = timeout + 1;
            if ((timeout % 10000) == 0) begin
                $display("  [%0d] running...", timeout);
            end
        end

        $display("\n============================================================");
        if (dut.done !== 1'b1) begin
            $display(" * FAILED * Timeout after %0d cycles!", timeout);
            $display("  C00:0x%08h C01:0x%08h C02:0x%08h C03:0x%08h", dut.debug_pc0, dut.debug_pc1, dut.debug_pc2, dut.debug_pc3);
            $display("  C04:0x%08h C05:0x%08h C06:0x%08h C07:0x%08h", dut.debug_pc4, dut.debug_pc5, dut.debug_pc6, dut.debug_pc7);
            $display("  C08:0x%08h C09:0x%08h C10:0x%08h C11:0x%08h", dut.debug_pc8, dut.debug_pc9, dut.debug_pc10, dut.debug_pc11);
            $display("  C12:0x%08h C13:0x%08h C14:0x%08h C15:0x%08h", dut.debug_pc12, dut.debug_pc13, dut.debug_pc14, dut.debug_pc15);
            $display("  C16:0x%08h C17:0x%08h C18:0x%08h C19:0x%08h", dut.debug_pc16, dut.debug_pc17, dut.debug_pc18, dut.debug_pc19);
            $display("  C20:0x%08h C21:0x%08h C22:0x%08h C23:0x%08h", dut.debug_pc20, dut.debug_pc21, dut.debug_pc22, dut.debug_pc23);
            $display("  C24:0x%08h C25:0x%08h C26:0x%08h C27:0x%08h", dut.debug_pc24, dut.debug_pc25, dut.debug_pc26, dut.debug_pc27);
            $display("  C28:0x%08h C29:0x%08h C30:0x%08h C31:0x%08h", dut.debug_pc28, dut.debug_pc29, dut.debug_pc30, dut.debug_pc31);
        end else begin
            $display(" Sorting completed. Cycles=%0d (cnt_test=%0d)", timeout, dut.cnt_test);

            err_cnt = 0;
            for (i = 0; i < N_DATA - 1; i = i + 1) begin
                if (result[i] > result[i+1]) begin
                    if (err_cnt < 10)
                        $display("  ORDER ERR [%0d]: %h > [%0d]: %h", i, result[i], i+1, result[i+1]);
                    err_cnt = err_cnt + 1;
                end
            end

            if (err_cnt == 0)
                $display(" * PASS * : All %0d elements in ascending order!", N_DATA);
            else
                $display(" * FAILED * : %0d ordering errors!", err_cnt);
        end
        $display("============================================================");
        $finish;
    end

endmodule
